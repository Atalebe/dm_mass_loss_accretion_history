#!/usr/bin/env bash
if (
 trap - ERR 2>/dev/null || true
 set +e; set +u; set +E; set +x
 set +o pipefail 2>/dev/null || true
 ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)" || exit 2
 cd "$ROOT" || exit 2
 export PYTHONDONTWRITEBYTECODE=1 PYTHONNOUSERSITE=1
 python3 -B verify_bundle.py || exit 2
 command -v xelatex >/dev/null 2>&1 || { printf '%s\n' 'HOLD: select/install an independent TeX environment; nothing installed.'; exit 2; }
 [ ! -e output ] || { printf '%s\n' 'HOLD: output already exists; retain it and compile a fresh project copy.'; exit 2; }
 mkdir output || exit 2
 export SOURCE_DATE_EPOCH=1792454400 FORCE_SOURCE_DATE=1 TZ=UTC
 for DOC in main supplementary; do
  for PASS in 1 2 3; do
   xelatex -interaction=nonstopmode -halt-on-error -file-line-error -no-shell-escape -output-directory=output "$DOC.tex" >"output/${DOC}_${PASS}.txt" 2>&1 || exit 2
  done
 done
 python3 -B - <<'PYBUILD'
from pathlib import Path
import json,re
for d in ['main','supplementary']:
 t=(Path('output')/(d+'.log')).read_text(errors='replace')
 if any(x in t for x in ['Overfull \\hbox','Overfull \\vbox','undefined references','Rerun to get cross-references right']):raise RuntimeError('HOLD: unresolved document diagnostics')
with Path('output/BUILD_COMPLETE.json').open('x') as f:json.dump({'status':'BOTH_DOCUMENTS_COMPILED','engine':'xelatex','scientific_execution':False},f,indent=2)
PYBUILD
); then printf '%s\n' 'BUILD_CHILD_STATUS=0'; else printf '%s\n' 'BUILD_CHILD_STATUS=2; HOLD_NO_LOGBOOK_OR_COMMIT'; fi
printf '%s\n' 'CALLER_TERMINAL_PRESERVED=true'
