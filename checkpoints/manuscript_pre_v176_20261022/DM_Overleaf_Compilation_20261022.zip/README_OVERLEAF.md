# Overleaf compilation project

This is a frozen compilation copy of the published manuscript and its supplement, not a new scientific revision.

## Import and compile

In Overleaf choose New Project -> Upload Project and upload DM_Overleaf_Compilation_20261022.zip directly. Do not upload the larger preservation ZIP as an Overleaf project. The two top-level documents are main.tex and supplementary.tex. Select XeLaTeX, then select main.tex as the Main document. To build the supplement, change the Main document to supplementary.tex and recompile. Both main documents are already at the project root.

The latexmkrc selects XeLaTeX for local LatexMk and fixes the PDF timestamp used for the reference build. In Overleaf explicitly select XeLaTeX as well. Use a current available TeX Live version; exact appearance may depend on its package versions. The final verification record states the locally tested engines. An actual Overleaf-hosted build is not claimed.

All required table inputs, vector figures and reference entries are included. The bibliography is in references.tex using the existing thebibliography/natbib arrangement; no missing .bib file or BibTeX run is required. No simulation data, Python, credentials, network download of data, custom font upload, or private repository is required for typesetting. Fonts and LaTeX packages are supplied by the selected TeX distribution.

## What changed for portability

Only the graphicspath in the two root documents changes from ../figures/ to figures/. Every other byte of those two documents, all 24 table fragments, eight PDF figures, the bibliography and the Data Availability source are preserved. SOURCE_MAP.json records the exact repository paths and hashes. No wording, values, affiliations or claims are changed.

Manuscript DOI: 10.5281/zenodo.23530614. Analysis v1.0.0 DOI: 10.5281/zenodo.23529740. Source commit: c46f207dad827ad44d4af2aa8958b6dba81a76dd.

## Verification and local compilation

python3 verify_bundle.py checks SHA256SUMS.txt before a build. bash build_no_exit.sh runs the hash/dependency checks and compiles both documents using an existing xelatex executable. It never installs packages. It retains logs and stops on errors. Its outer wrapper keeps the terminal open: check BUILD_CHILD_STATUS and output/BUILD_COMPLETE.json rather than interpreting the wrapper return code as scientific success. No logbook or Git action is performed by that wrapper.

The larger checkpoint ZIP preserves the exact published article, supplement, all manuscript sources, all figure representations and underlying figure/summary tables, plus provenance and the checkpoint handoff. Keep that ZIP unchanged; use a copy of this project for later editing. The numerical archive remains the separate published analysis DOI. This bundle does not close spatial-calibration or missing-population findings and does not start v176.

Original scripts are MIT; all other author-owned material is CC BY 4.0. Third-party rights remain unchanged. See LICENSE.md and LICENSES/. No font files are distributed.

Official Overleaf guidance: https://docs.overleaf.com/managing-projects-and-files/uploading-a-project and https://docs.overleaf.com/getting-started/recompiling-your-project/the-main-document
