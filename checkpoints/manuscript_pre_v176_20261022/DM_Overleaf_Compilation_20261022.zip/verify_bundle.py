"""Verify the unedited frozen bundle; no third-party Python dependencies."""
from pathlib import Path, PurePosixPath
import hashlib,json,re
ROOT=Path(__file__).resolve().parent

def verify(root=ROOT):
 root=Path(root);entries={}
 for line in (root/'SHA256SUMS.txt').read_text().splitlines():
  digest,name=line.split('  ',1);q=PurePosixPath(name)
  if q.is_absolute() or '..' in q.parts or name in entries:raise RuntimeError('Unsafe/duplicate checksum path')
  p=root/name
  if p.is_symlink() or not p.is_file() or hashlib.sha256(p.read_bytes()).hexdigest()!=digest:raise RuntimeError('HOLD: changed or missing file: '+name)
  entries[name]=digest
 for p in root.rglob('*'):
  if p.is_symlink():raise RuntimeError('HOLD: symlink found')
 for src in ('main.tex','supplementary.tex'):
  text=(root/src).read_text()
  for target in re.findall(r'\\input\{([^}]+)\}',text):
   if not (root/target).is_file():raise RuntimeError('Missing input: '+target)
  for target in re.findall(r'\\includegraphics(?:\[[^\]]*\])?\{([^}]+)\}',text):
   if not (root/'figures'/target).is_file():raise RuntimeError('Missing figure: '+target)
 return {'status':'FROZEN_OVERLEAF_INPUTS_VERIFIED','files':len(entries),'scientific_execution':False}
if __name__=='__main__':print(json.dumps(verify(),indent=2))
