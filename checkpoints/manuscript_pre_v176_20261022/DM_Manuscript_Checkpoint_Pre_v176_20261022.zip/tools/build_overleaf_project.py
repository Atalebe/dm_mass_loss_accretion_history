"""Create a document-only Overleaf project from an exact paper repository snapshot."""
from pathlib import Path, PurePosixPath
import argparse, hashlib, json, re, zipfile

BASE='c46f207dad827ad44d4af2aa8958b6dba81a76dd'
MANUSCRIPT='10.5281/zenodo.23530614'
ANALYSIS='10.5281/zenodo.23529740'
OLD=rb'\graphicspath{{../figures/}}'
NEW=rb'\graphicspath{{figures/}}'
TITLE='Mass-loss dependence of accretion-history correlations in dark-matter halo velocity structure'

def need(ok,message):
    if not bool(ok):raise RuntimeError(message)
def sha(b):return hashlib.sha256(b).hexdigest()
def write(p,b):
    p.parent.mkdir(parents=True,exist_ok=True)
    with p.open('xb') as f:f.write(b)
def js(o):return (json.dumps(o,indent=2,sort_keys=True)+'\n').encode()
def items(root):
    out={}
    for p in sorted(root.rglob('*')):
        need(not p.is_symlink(),'Symlink forbidden')
        if p.is_file():out[str(p.relative_to(root))]=p.read_bytes()
    return out

def deterministic_zip(root,path):
    need(not path.exists(),'Archive exists')
    with zipfile.ZipFile(path,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for name,b in items(root).items():
            info=zipfile.ZipInfo(name,date_time=(2026,10,22,0,0,0))
            info.compress_type=zipfile.ZIP_DEFLATED;info.create_system=3;info.external_attr=0o100644<<16
            z.writestr(info,b,compress_type=zipfile.ZIP_DEFLATED,compresslevel=9)
    with zipfile.ZipFile(path) as z:need(z.testzip() is None,'ZIP integrity failure')

def dependencies(root):
    seen=set();inputs=set();figures=set()
    def scan(name):
        need(name not in ['','..'] and not PurePosixPath(name).is_absolute(),'Unsafe TeX name')
        if name in seen:return
        seen.add(name);p=root/name;need(p.is_file(),'Missing input: '+name)
        text=p.read_text();text=re.sub(r'(?<!\\)%[^\n]*','',text)
        for child in re.findall(r'\\(?:input|include)\{([^}]+)\}',text):
            child=child if Path(child).suffix else child+'.tex';need('..' not in PurePosixPath(child).parts,'Escaping input')
            inputs.add(child);scan(child)
        for f in re.findall(r'\\includegraphics(?:\[[^\]]*\])?\{([^}]+)\}',text):
            rel='figures/'+f;need((root/rel).is_file(),'Missing figure: '+rel);figures.add(rel)
    scan('main.tex');scan('supplementary.tex')
    need(len([n for n in inputs if n.startswith('tables/')])==24,'Expected 24 table inputs')
    need(len(figures)==8,'Expected eight figures')
    return {'table_inputs':24,'figure_inputs':8,'tex_files_reached':len(seen)}

README='''# Overleaf compilation project\n\nThis is a frozen compilation copy of the published manuscript and its supplement, not a new scientific revision.\n\n## Import and compile\n\nIn Overleaf choose New Project -> Upload Project and upload DM_Overleaf_Compilation_20261022.zip directly. Do not upload the larger preservation ZIP as an Overleaf project. The two top-level documents are main.tex and supplementary.tex. Select XeLaTeX, then select main.tex as the Main document. To build the supplement, change the Main document to supplementary.tex and recompile. Both main documents are already at the project root.\n\nThe latexmkrc selects XeLaTeX for local LatexMk and fixes the PDF timestamp used for the reference build. In Overleaf explicitly select XeLaTeX as well. Use a current available TeX Live version; exact appearance may depend on its package versions. The final verification record states the locally tested engines. An actual Overleaf-hosted build is not claimed.\n\nAll required table inputs, vector figures and reference entries are included. The bibliography is in references.tex using the existing thebibliography/natbib arrangement; no missing .bib file or BibTeX run is required. No simulation data, Python, credentials, network download of data, custom font upload, or private repository is required for typesetting. Fonts and LaTeX packages are supplied by the selected TeX distribution.\n\n## What changed for portability\n\nOnly the graphicspath in the two root documents changes from ../figures/ to figures/. Every other byte of those two documents, all 24 table fragments, eight PDF figures, the bibliography and the Data Availability source are preserved. SOURCE_MAP.json records the exact repository paths and hashes. No wording, values, affiliations or claims are changed.\n\nManuscript DOI: 10.5281/zenodo.23530614. Analysis v1.0.0 DOI: 10.5281/zenodo.23529740. Source commit: c46f207dad827ad44d4af2aa8958b6dba81a76dd.\n\n## Verification and local compilation\n\npython3 verify_bundle.py checks SHA256SUMS.txt before a build. bash build_no_exit.sh runs the hash/dependency checks and compiles both documents using an existing xelatex executable. It never installs packages. It retains logs and stops on errors. Its outer wrapper keeps the terminal open: check BUILD_CHILD_STATUS and output/BUILD_COMPLETE.json rather than interpreting the wrapper return code as scientific success. No logbook or Git action is performed by that wrapper.\n\nThe larger checkpoint ZIP preserves the exact published article, supplement, all manuscript sources, all figure representations and underlying figure/summary tables, plus provenance and the checkpoint handoff. Keep that ZIP unchanged; use a copy of this project for later editing. The numerical archive remains the separate published analysis DOI. This bundle does not close spatial-calibration or missing-population findings and does not start v176.\n\nOriginal scripts are MIT; all other author-owned material is CC BY 4.0. Third-party rights remain unchanged. See LICENSE.md and LICENSES/. No font files are distributed.\n\nOfficial Overleaf guidance: https://docs.overleaf.com/managing-projects-and-files/uploading-a-project and https://docs.overleaf.com/getting-started/recompiling-your-project/the-main-document\n'''
VERIFY=r'''"""Verify the unedited frozen bundle; no third-party Python dependencies."""
from pathlib import Path, PurePosixPath
import hashlib,json,re
ROOT=Path(__file__).resolve().parent

def verify(root=ROOT):
 root=Path(root);entries={}
 for line in (root/'SHA256SUMS.txt').read_text().splitlines():
  digest,name=line.split('  ',1);q=PurePosixPath(name)
  if q.is_absolute() or '..' in q.parts or name in entries:raise RuntimeError('Unsafe/duplicate checksum path')
  p=root/name
  if p.is_symlink() or not p.is_file() or hashlib.sha256(p.read_bytes()).hexdigest()!=digest:raise RuntimeError('HOLD: changed or missing file: '+name)
  entries[name]=digest
 for p in root.rglob('*'):
  if p.is_symlink():raise RuntimeError('HOLD: symlink found')
 for src in ('main.tex','supplementary.tex'):
  text=(root/src).read_text()
  for target in re.findall(r'\\input\{([^}]+)\}',text):
   if not (root/target).is_file():raise RuntimeError('Missing input: '+target)
  for target in re.findall(r'\\includegraphics(?:\[[^\]]*\])?\{([^}]+)\}',text):
   if not (root/'figures'/target).is_file():raise RuntimeError('Missing figure: '+target)
 return {'status':'FROZEN_OVERLEAF_INPUTS_VERIFIED','files':len(entries),'scientific_execution':False}
if __name__=='__main__':print(json.dumps(verify(),indent=2))
'''
BUILD=r'''#!/usr/bin/env bash
if (
 trap - ERR 2>/dev/null || true
 set +e; set +u; set +E; set +x
 set +o pipefail 2>/dev/null || true
 ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)" || exit 2
 cd "$ROOT" || exit 2
 export PYTHONDONTWRITEBYTECODE=1 PYTHONNOUSERSITE=1
 python3 -B verify_bundle.py || exit 2
 command -v xelatex >/dev/null 2>&1 || { printf '%s\n' 'HOLD: select/install an independent TeX environment; nothing installed.'; exit 2; }
 [ ! -e output ] || { printf '%s\n' 'HOLD: output already exists; retain it and compile a fresh project copy.'; exit 2; }
 mkdir output || exit 2
 export SOURCE_DATE_EPOCH=1792454400 FORCE_SOURCE_DATE=1 TZ=UTC
 for DOC in main supplementary; do
  for PASS in 1 2 3; do
   xelatex -interaction=nonstopmode -halt-on-error -file-line-error -no-shell-escape -output-directory=output "$DOC.tex" >"output/${DOC}_${PASS}.txt" 2>&1 || exit 2
  done
 done
 python3 -B - <<'PYBUILD'
from pathlib import Path
import json,re
for d in ['main','supplementary']:
 t=(Path('output')/(d+'.log')).read_text(errors='replace')
 if any(x in t for x in ['Overfull \\hbox','Overfull \\vbox','undefined references','Rerun to get cross-references right']):raise RuntimeError('HOLD: unresolved document diagnostics')
with Path('output/BUILD_COMPLETE.json').open('x') as f:json.dump({'status':'BOTH_DOCUMENTS_COMPILED','engine':'xelatex','scientific_execution':False},f,indent=2)
PYBUILD
); then printf '%s\n' 'BUILD_CHILD_STATUS=0'; else printf '%s\n' 'BUILD_CHILD_STATUS=2; HOLD_NO_LOGBOOK_OR_COMMIT'; fi
printf '%s\n' 'CALLER_TERMINAL_PRESERVED=true'
'''

def assemble(source,out):
    need(not out.exists(),'Refusing existing output')
    source=source.resolve();old=json.loads((source/'MANIFEST.json').read_text());lookup={x['path']:x for x in old['files']}
    project=out/'overleaf';project.mkdir(parents=True)
    mapping=[];paper=items(source/'paper')
    for name,b in paper.items():
        key='paper/'+name;need(key in lookup and sha(b)==lookup[key]['sha256'],'Source manifest mismatch: '+key)
        write(out/'canonical_paper'/name,b)
    for name,b in paper.items():
        if name.startswith('manuscript/'):
            dest=name[len('manuscript/'):]
            if dest in ('main.tex','supplementary.tex'):
                need(b.count(OLD)==1,'Expected one graphicspath');changed=b.replace(OLD,NEW)
                need(changed.replace(NEW,OLD)==b,'Non-reversible source change')
            else:changed=b
        elif name.startswith('figures/') and name.endswith('.pdf'):dest=name;changed=b
        else:continue
        write(project/dest,changed)
        mapping.append({'bundle_path':dest,'repository_path':'paper/'+name,'source_sha256':sha(b),'bundle_sha256':sha(changed),'transformation':'graphicspath_only' if b!=changed else 'byte_exact'})
    for path in ['LICENSE.md','LICENSES/MIT.txt','LICENSES/CC-BY-4.0.txt']:
        b=(source/path).read_bytes();write(project/path,b)
    write(project/'README_OVERLEAF.md',README.encode())
    write(project/'latexmkrc',b"$pdf_mode = 5;\n$max_repeat = 5;\n$ENV{'SOURCE_DATE_EPOCH'}='1792454400';\n$ENV{'FORCE_SOURCE_DATE'}='1';\n$ENV{'TZ'}='UTC';\n")
    write(project/'verify_bundle.py',VERIFY.encode());write(project/'build_no_exit.sh',BUILD.encode())
    write(project/'SOURCE_MAP.json',js({'source_commit':BASE,'manuscript_doi':MANUSCRIPT,'analysis_doi':ANALYSIS,'files':mapping}))
    dep=dependencies(project)
    payload=items(project)
    write(project/'SHA256SUMS.txt',''.join(sha(b)+'  '+n+'\n' for n,b in payload.items()).encode())
    need(len(items(project))<180,'Overleaf upload file-count limit')
    need(sum(len(b) for n,b in items(project).items() if not n.endswith('.pdf'))<7*1024**2,'Overleaf editable-size limit')
    deterministic_zip(project,out/'DM_Overleaf_Compilation_20261022.zip')
    record={'status':'ASSEMBLED_NOT_YET_BUILD_VERIFIED','source_commit':BASE,'canonical_paper_files':len(paper),'canonical_paper_bytes':sum(map(len,paper.values())),'overleaf_files':len(items(project)),'overleaf_zip_bytes':(out/'DM_Overleaf_Compilation_20261022.zip').stat().st_size,'overleaf_zip_sha256':sha((out/'DM_Overleaf_Compilation_20261022.zip').read_bytes()),'dependencies':dep,'source_changes':'Two graphicspath relocations only','new_scientific_computations':0,'v176_started':False}
    write(out/'ASSEMBLY.json',js(record));print(json.dumps(record,indent=2))
if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--source',type=Path,required=True);ap.add_argument('--out',type=Path,required=True);a=ap.parse_args();assemble(a.source,a.out)
